#!/usr/bin/env bash
set -euo pipefail

START_URL="${1:-http://10.34.100.110:8031/index.php/publicknowledge/}"
SCOPE_PREFIX="${2:-http://10.34.100.110:8031/index.php/publicknowledge}"
FOCUS_SEED_URLS="${3:-management/settings/website,admin/index,submissions,manageIssues,management/settings/publication}"
OJS_USERNAME="${OJS_USERNAME:-admin}"
OJS_PASSWORD="${OJS_PASSWORD:-admin}"
SESSIONS="${SESSIONS:-5}"
MAX_STEPS="${MAX_STEPS:-25}"
FOCUS_PROB="${FOCUS_PROB:-0.8}"
ENABLE_DUMMY_UPLOAD="${ENABLE_DUMMY_UPLOAD:-1}"
SUBMIT_DUMMY_UPLOAD="${SUBMIT_DUMMY_UPLOAD:-1}"
MAX_DUMMY_UPLOADS_PER_SESSION="${MAX_DUMMY_UPLOADS_PER_SESSION:-1}"
export OJS_PASSWORD
PYTHON_BIN="${PYTHON_BIN:-}"

if [[ -z "$PYTHON_BIN" && -x ".venv/bin/python" ]]; then
  PYTHON_BIN=".venv/bin/python"
fi

PYTHON_BIN="${PYTHON_BIN:-python3}"

EXTRA_ARGS=()
if [[ "$ENABLE_DUMMY_UPLOAD" == "1" ]]; then
  EXTRA_ARGS+=(--enable-dummy-upload)
  EXTRA_ARGS+=(--max-dummy-uploads-per-session "$MAX_DUMMY_UPLOADS_PER_SESSION")
fi

if [[ "$SUBMIT_DUMMY_UPLOAD" == "1" ]]; then
  EXTRA_ARGS+=(--submit-dummy-upload)
fi

"$PYTHON_BIN" normal_activity_crawler.py \
  --start-url "$START_URL" \
  --scope-prefix "$SCOPE_PREFIX" \
  --username "$OJS_USERNAME" \
  --password-env OJS_PASSWORD \
  --admin-start-url "$FOCUS_SEED_URLS" \
  --focus-admin-upload \
  --focus-seed-urls "$FOCUS_SEED_URLS" \
  --focus-prob "$FOCUS_PROB" \
  --sessions "$SESSIONS" \
  --max-steps "$MAX_STEPS" \
  --delay-min 1.5 \
  --delay-max 4.0 \
  --enable-search \
  --search-prob 0.1 \
  --out-jsonl dataset_ojs_admin_upload_focus.jsonl \
  --out-csv dataset_ojs_admin_upload_focus.csv \
  "${EXTRA_ARGS[@]}"
