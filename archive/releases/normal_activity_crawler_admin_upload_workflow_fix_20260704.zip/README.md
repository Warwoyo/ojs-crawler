# Normal Activity Web Crawler

Tool ini dibuat untuk membuat **dataset aktivitas normal user** pada web/app yang Anda miliki atau lingkungan lab yang authorized.

## Tujuan

Dataset ini cocok untuk penelitian seperti:

- baseline normal web interaction
- klasifikasi normal vs abnormal traffic
- observasi alur user pada aplikasi web
- pembuatan dataset aktivitas normal sebelum dibandingkan dengan aktivitas anomali

Tool ini **bukan pentest tool**. Script tidak melakukan fuzzing, brute force, exploit, payload injection, atau scraping agresif. Upload file dummy hanya dilakukan jika mode dummy upload diaktifkan eksplisit.

## Instalasi Linux

```bash
sudo apt update
sudo apt install -y python3 python3-venv

python3 -m venv .venv
source .venv/bin/activate

pip install -r requirements.txt
playwright install chromium
```

Jika Chromium butuh dependency OS tambahan:

```bash
playwright install-deps chromium
```

## Contoh untuk OJS lab lokal

```bash
python3 normal_activity_crawler.py \
  --start-url "http://10.34.100.102:8033/index.php/javd-journal" \
  --scope-prefix "http://10.34.100.102:8033/index.php/javd-journal" \
  --sessions 20 \
  --max-steps 30 \
  --delay-min 1.5 \
  --delay-max 4.0 \
  --enable-search \
  --search-terms "cybersecurity,ojs,security,article,journal" \
  --out-jsonl dataset_ojs_normal.jsonl \
  --out-csv dataset_ojs_normal.csv
```

Untuk melihat browser secara langsung:

```bash
python3 normal_activity_crawler.py \
  --start-url "http://10.34.100.102:8033/index.php/javd-journal" \
  --scope-prefix "http://10.34.100.102:8033/index.php/javd-journal" \
  --sessions 1 \
  --max-steps 10 \
  --headful
```

## Contoh login admin OJS

Gunakan mode ini hanya pada web/app yang Anda miliki atau lab yang authorized. Password bisa dikirim lewat environment variable agar tidak masuk shell history.

```bash
export OJS_PASSWORD='admin'

python3 normal_activity_crawler.py \
  --start-url "http://10.34.100.110:8031/index.php/publicknowledge/" \
  --scope-prefix "http://10.34.100.110:8031/index.php/publicknowledge" \
  --username "admin" \
  --password-env OJS_PASSWORD \
  --admin-start-url "submissions" \
  --enable-dummy-upload \
  --submit-dummy-upload \
  --max-dummy-uploads-per-session 1 \
  --sessions 5 \
  --max-steps 20 \
  --delay-min 1.5 \
  --delay-max 4.0 \
  --out-jsonl dataset_ojs_admin_normal.jsonl \
  --out-csv dataset_ojs_admin_normal.csv
```

Catatan:

- Jika `--username` diisi, crawler otomatis membuka `<start-url>/login`, submit login, lalu mulai dari `--admin-start-url` atau `submissions` jika tidak diisi.
- `--admin-start-url` bisa berupa URL penuh, path, atau segment relatif seperti `management`, `admin`, atau `submissions`.
- Pada target `publicknowledge` ini, kredensial `admin/admin` berhasil masuk ke `submissions`; route `management` bisa menghasilkan role-based access denied jika akun belum punya role journal manager/site admin.
- Default deny-regex admin membolehkan route seperti `admin`, `management`, `settings`, `dashboard`, dan `workflow`, tetapi tetap menghindari link seperti logout, delete, edit, submit, upload, export, password/profile, dan action lain yang berpotensi mengubah data.
- Untuk melihat browser admin berjalan, tambahkan `--headful`.

### Dummy upload untuk log OJS

Untuk mengumpulkan log mekanisme upload, aktifkan:

```bash
export OJS_PASSWORD='admin'

.venv/bin/python normal_activity_crawler.py \
  --start-url "http://10.34.100.110:8031/index.php/publicknowledge/" \
  --scope-prefix "http://10.34.100.110:8031/index.php/publicknowledge" \
  --username "admin" \
  --password-env OJS_PASSWORD \
  --admin-start-url "management/settings/website" \
  --enable-dummy-upload \
  --submit-dummy-upload \
  --max-dummy-uploads-per-session 1 \
  --sessions 1 \
  --max-steps 3 \
  --out-jsonl dataset_ojs_upload_normal.jsonl \
  --out-csv dataset_ojs_upload_normal.csv
```

Perilaku upload:

- Crawler mencari `input[type=file]` langsung atau link action OJS seperti `Upload` / `show-file-upload-form`.
- Jika form upload memakai `accept` image, crawler membuat dummy PNG kecil. Untuk CSS membuat dummy `.css`, untuk PDF membuat dummy `.pdf`, selain itu `.txt`.
- `--enable-dummy-upload` memasang file dummy ke input file.
- `--submit-dummy-upload` mencoba klik tombol Upload/submit pada form upload agar request upload tercatat di log server.
- Event upload dicatat sebagai `dummy_upload`, `dummy_upload_attempted`, `dummy_upload_prepared`, atau `dummy_upload_skipped`.

## Mode fokus admin dan upload

Mode ini tetap melakukan crawl normal, tetapi memilih link admin/settings/submissions/upload lebih sering. Cocok untuk dataset log yang ingin memperbanyak aktivitas area admin dan mekanisme upload tanpa menghilangkan perilaku browsing biasa.

```bash
./run_ojs_admin_upload_focus.sh
```

Atau manual:

```bash
export OJS_PASSWORD='admin'

.venv/bin/python normal_activity_crawler.py \
  --start-url "http://10.34.100.110:8031/index.php/publicknowledge/" \
  --scope-prefix "http://10.34.100.110:8031/index.php/publicknowledge" \
  --username "admin" \
  --password-env OJS_PASSWORD \
  --admin-start-url "management/settings/website,admin/index,submissions,manageIssues,management/settings/publication" \
  --focus-admin-upload \
  --focus-seed-urls "management/settings/website,admin/index,submissions,manageIssues,management/settings/publication" \
  --focus-prob 0.8 \
  --enable-dummy-upload \
  --submit-dummy-upload \
  --max-dummy-uploads-per-session 1 \
  --enable-search \
  --search-prob 0.1 \
  --sessions 5 \
  --max-steps 25 \
  --out-jsonl dataset_ojs_admin_upload_focus.jsonl \
  --out-csv dataset_ojs_admin_upload_focus.csv
```

Parameter penting:

- `--focus-admin-upload`: aktifkan prioritas link admin/upload.
- `--focus-prob 0.8`: sekitar 80% pemilihan link akan condong ke admin/upload jika kandidatnya ada; sisanya tetap normal.
- `--focus-seed-urls`: daftar halaman admin/upload yang bisa dipakai sebagai titik balik ketika crawler keluar dari area fokus.
- `--upload-scan-wait-ms 800`: waktu tunggu singkat untuk link/form upload OJS yang muncul lewat AJAX. Set `0` kalau ingin scan upload benar-benar tanpa menunggu.
- `MAX_DUMMY_UPLOADS_PER_SESSION=2 ./run_ojs_admin_upload_focus.sh`: contoh menaikkan jumlah upload dummy per sesi.

Jika mengganti journal path, cukup kirim URL sebagai argumen pertama. Runner akan otomatis memakai URL itu sebagai scope:

```bash
./run_ojs_admin_activity.sh "http://10.34.100.110:8031/index.php/efgh/"

./run_ojs_admin_upload_focus.sh "http://10.34.100.110:8031/index.php/efgh/"
```

Kalau jurnal/rute tersebut belum punya halaman upload yang mudah ditemukan, jalankan dengan scan upload lebih cepat:

```bash
UPLOAD_SCAN_WAIT_MS=0 ./run_ojs_admin_activity.sh "http://10.34.100.110:8031/index.php/efgh/"
```

## Kolom dataset

| Kolom | Makna |
|---|---|
| timestamp_utc | waktu event |
| session_id | ID sesi user sintetis |
| step | urutan langkah dalam sesi |
| event_type | page_view, navigation, search, blocked_by_robots |
| action | jenis aksi |
| url_before | URL sebelum aksi |
| url_after | URL setelah aksi |
| http_status | HTTP status dari navigasi |
| load_time_ms | durasi load halaman |
| page_title | judul halaman |
| candidate_count | jumlah link internal aman yang ditemukan |
| chosen_text | teks link atau keyword search |
| chosen_href | URL yang dipilih |
| content_sha256 | hash isi halaman, bukan raw text |
| viewport | ukuran layar browser |
| user_agent | user-agent yang digunakan |
| error | error jika ada |

## Catatan metodologi

Agar ilmiah, simpan konfigurasi eksperimen:

- target URL
- jumlah sesi
- jumlah step per sesi
- delay min/max
- seed random bila ingin replikasi
- deny-regex yang digunakan
- apakah robots.txt aktif atau tidak

Contoh replikasi:

```bash
python3 normal_activity_crawler.py \
  --start-url "http://10.34.100.102:8033/index.php/javd-journal" \
  --scope-prefix "http://10.34.100.102:8033/index.php/javd-journal" \
  --sessions 30 \
  --max-steps 25 \
  --delay-min 2 \
  --delay-max 5 \
  --seed 42 \
  --out-jsonl run_seed42.jsonl \
  --out-csv run_seed42.csv
```

## Batasan

- Login otomatis hanya untuk form login sederhana/OJS-like dengan username dan password.
- Tidak mengisi form kompleks selain login dan search benign.
- Upload file hanya dilakukan saat `--enable-dummy-upload` aktif; submit upload ke server memerlukan `--submit-dummy-upload`.
- Mode publik tidak mengakses URL yang mengandung kata sensitif pada deny-regex default seperti admin, management, delete, edit, token, importexport, dan sebagainya.
- Mode admin punya deny-regex terpisah yang membolehkan area admin, tetapi tetap menghindari aksi yang berpotensi mengubah data.
