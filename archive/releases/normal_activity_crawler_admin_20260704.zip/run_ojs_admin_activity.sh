#!/usr/bin/env bash
set -euo pipefail

START_URL="${1:-http://10.34.100.110:8031/index.php/publicknowledge/}"
SCOPE_PREFIX="${2:-http://10.34.100.110:8031/index.php/publicknowledge}"
ADMIN_START_URL="${3:-submissions}"
OJS_USERNAME="${OJS_USERNAME:-admin}"
OJS_PASSWORD="${OJS_PASSWORD:-admin}"
export OJS_PASSWORD
PYTHON_BIN="${PYTHON_BIN:-}"

if [[ -z "$PYTHON_BIN" && -x ".venv/bin/python" ]]; then
  PYTHON_BIN=".venv/bin/python"
fi

PYTHON_BIN="${PYTHON_BIN:-python3}"

"$PYTHON_BIN" normal_activity_crawler.py \
  --start-url "$START_URL" \
  --scope-prefix "$SCOPE_PREFIX" \
  --username "$OJS_USERNAME" \
  --password-env OJS_PASSWORD \
  --admin-start-url "$ADMIN_START_URL" \
  --sessions 5 \
  --max-steps 20 \
  --delay-min 1.5 \
  --delay-max 4.0 \
  --out-jsonl dataset_ojs_admin_normal.jsonl \
  --out-csv dataset_ojs_admin_normal.csv
